package employee;

public abstract class Employees {

    private String name;
    private String position;
    double basicSalary;
    private double salary;
    private int experience;
    private String educationalLevel;
    protected double bonus;

    public Employees(String name, String position, int experience, double basicSalary, String educationalLevel) {
        this.name = name;
        this.position = position;
        this.basicSalary = basicSalary;
        this.experience = experience;
        this.educationalLevel = educationalLevel;
        calculateSalary();
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    public int getExperience() {
        return experience;
    }

    public String getEducationalLevel() {
        return educationalLevel;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public void setEducationalLevel(String educationalLevel) {
        this.educationalLevel = educationalLevel;
    }

    private void calculateSalary() {
        double tempSalary = this.basicSalary + (this.basicSalary * 0.05 * this.experience);
        double educationalLevelBonus = 0;
        if (educationalLevel.equals("Bachelor Degree")) {
            educationalLevelBonus = 500;
        } else if (educationalLevel.equals("diploma ")) {
            educationalLevelBonus = 250;
        }
        this.salary = tempSalary + educationalLevelBonus;
    }

    protected abstract void calculateBonusSalary();
}
