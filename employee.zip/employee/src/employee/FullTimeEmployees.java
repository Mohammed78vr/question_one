package employee;

public class FullTimeEmployees extends Employees {

    public FullTimeEmployees(String name, String position, int experience, double basicSalary, String educationalLevel) {
        super(name, position, experience, basicSalary, educationalLevel);
    }

    @Override
    protected void calculateBonusSalary() {
        bonus = basicSalary * 0.03;
    }

}
