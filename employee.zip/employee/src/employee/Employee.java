package employee;

public class Employee {

    public static void main(String[] args) {
        FullTimeEmployees emp1 = new FullTimeEmployees("Mohammed", "Software engineer", 0, 10000, "Bachelor Degree");
        FullTimeEmployees emp2 = new FullTimeEmployees("Ahmad", "DevOps engineer", 2, 10000, "");
        PartTimeEmployees emp3 = new PartTimeEmployees("Ali", "Front-end", 1, 10000, "diploma");
        PartTimeEmployees emp4 = new PartTimeEmployees("Mustafa", "Back-end", 1, 10000, "Bachelor Degree");
        
        printEmployeeDetails(emp1);
        printEmployeeDetails(emp2);
        printEmployeeDetails(emp3);
        printEmployeeDetails(emp4);
        
    }
    
    public static void printEmployeeDetails(Employees employee) {
        System.out.println("Employee Name: " + employee.getName());
        System.out.println("Position: " + employee.getPosition());
        System.out.println("Basic Salary: " + employee.basicSalary);
        System.out.println("Experience: " + employee.getExperience() + " years");
        System.out.println("Educational Level: " + employee.getEducationalLevel());
        System.out.println("Calculated Salary: " + employee.getSalary());
        System.out.println();
    }
    
}
